package Color;

public class Verde  implements Color{
    @Override
    public String rellenar(){
        return "Rellenando de Verde";
    }
    
}

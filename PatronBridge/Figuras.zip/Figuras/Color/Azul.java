package Color;

public class Azul implements Color{
    @Override
    public String rellenar(){
        return "Rellenando de Azul";
    }
}

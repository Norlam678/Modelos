package Color;

public class Rojo implements Color{
    
    @Override
    public String rellenar(){
        return "Rellenando de Rojo";
    }
}
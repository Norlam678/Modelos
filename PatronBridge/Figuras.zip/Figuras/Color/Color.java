package Color;

public interface Color{
    public String rellenar();
}

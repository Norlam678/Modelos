package TipoDePato;
public class PatoDeGoma extends Pato {
    public String mostrar (){
        return "Soy un pato de goma";
    }
}

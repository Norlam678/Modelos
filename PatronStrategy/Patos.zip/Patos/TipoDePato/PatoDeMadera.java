package TipoDePato;
public class PatoDeMadera extends Pato {
    
    public String mostrar (){
        return "Soy un pato de madera";
    }
}

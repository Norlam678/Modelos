package ComportamientoDeSonido;

public class Squeak implements ComportamientoDeSonido {
    @Override
    public String quack(){
        return "Squeak";
    }
}

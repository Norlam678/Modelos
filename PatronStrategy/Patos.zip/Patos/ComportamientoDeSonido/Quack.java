package ComportamientoDeSonido;

public class Quack implements ComportamientoDeSonido{
    
    @Override
    public String quack(){
        return "Quack";
    }
}
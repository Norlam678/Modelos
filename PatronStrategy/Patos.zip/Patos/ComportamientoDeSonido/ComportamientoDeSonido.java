package ComportamientoDeSonido;
public interface ComportamientoDeSonido {

    public String quack();
    
}
package ComportamientoDeVuelo;

public class VuelaConCohete implements ComportamientoDeVuelo {
    @Override
    public String volar(){
        return "El pato tiene un cohete, esta volando con el";
    }
}

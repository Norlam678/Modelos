package ComportamientoDeVuelo;

public class VueloConAlas implements ComportamientoDeVuelo {
    @Override
    public String volar(){
        return "El pato está volando con sus alas";
    }
}

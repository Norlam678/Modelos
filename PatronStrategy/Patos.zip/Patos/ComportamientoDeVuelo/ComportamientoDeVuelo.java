package ComportamientoDeVuelo;

public interface ComportamientoDeVuelo {

    public String volar();
    
}